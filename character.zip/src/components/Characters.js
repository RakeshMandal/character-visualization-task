import React, { useEffect, useState, useContext } from 'react'
import CharacterContext from '../context/CharacterContext';
import { Link } from 'react-router-dom';

const Characters = () => {

    const { setSelectedCharacterId } = useContext(CharacterContext);
    const [characters,setCharecters] = useState([]);
    const [page, setPage] = useState(1);
    const [searchtext, setSearchtext] = useState("");
    const [suggest, setSuggest] = useState([]);
    const [resfound, setResfound] = useState(true);

    useEffect(()=>{
       async function getCharacterfromAPI(){
            try{
                const response = await fetch(`https://rickandmortyapi.com/api/character/?page=${page}`)
                const data = await response.json()
                setCharecters(data.results)
            }
            catch(error)
            {
                console.error(error)
            }
        }
        getCharacterfromAPI()
    },[page]);

    const handleCharacterClick = (id) => {
        setSelectedCharacterId(id);
      };

      const nextPage = () => {
        setPage(prevPage => prevPage + 1);
      };
    
      const prevPage = () => {
        if (page > 1) {
          setPage(prevPage => prevPage - 1);
        }
      };

      // searching for character
      const handleChangeCharater =(e)=>{
        let searchval = e.target.value;
        let suggestion = [];
        if (searchval.length > 0) {
            suggestion = characters
              .sort()
              .filter((e) => e.toString().toLowerCase().includes(searchval.toLowerCase()));
              console.log("ee",suggestion.length)
            setResfound(suggestion.length !== 0 ? true : false);
          }
          setSuggest(suggestion);
          setSearchtext(searchval);
        };
       
        const suggestedText = (value) => {
            console.log(value);
            setSearchtext(value);
            setSuggest([]);
          };


          const getSuggestions = () => {
            if (suggest.length === 0 && searchtext !== "" && !resfound) {
              return <p>Search Content Not Found</p>;
            }
        
            return (
              <ul>
                {suggest.map((item, index) => {
                  return (
                    <div key={index}>
                      <li onClick={() => suggestedText(item)}>{item}</li>
                      {index !== suggest.length - 1 && <hr />}
                    </div>
                  );
                })}
              </ul>
            );
          };



  return (
    <>
    <h1 style={{textAlign:"center",color:"#222222"}}>Character Visualization Application</h1>
    
    
    <div className='prev-next-btn'>
        
    <div className='search-btn'>        
    <input onChange={handleChangeCharater} type='text' placeholder='Search your favorite Character.'/>
    {getSuggestions()}
    </div>
    <button onClick={prevPage} className='btn btn1'>Prev.</button>
    <button onClick={nextPage} className='btn btn1'>Next.</button>
    </div>
   
    <div className='showed-characters'>
      {
        characters.map((item,id)=>(
            <div key={id} className='character-showing'>
            <Link to={`/character/${item.id}`} onClick={() => handleCharacterClick(item.id)}>

                <img src={item.image} alt={item.name}/>
                <h3>{item.name}</h3>
             </Link>
            </div>
        ))
      }
    </div>
    </>
  )
}

export default Characters
