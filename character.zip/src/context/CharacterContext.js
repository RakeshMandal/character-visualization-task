import { createContext } from "react";

const CharacterContext = createContext()

export default CharacterContext;